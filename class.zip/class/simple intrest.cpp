#include<iostream>
using namespace std;
class class1
{
	private:
		int p,n,r;
		float s;
		public:
			void input()
			{
				cout<<"enter p,n,r:";
				cin>>p>>n>>r;
				
			}
			void process()
			{
				s=p*n*r/100;
				
			}
			void output()
			{
			cout<<"simple interest is:"<<s;	
			}
};
			int main()
			{
				class class1 c1;
				c1.input();
				c1.process();
				c1.output();
			}
