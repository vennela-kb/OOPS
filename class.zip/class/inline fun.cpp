#include<iostream>
using namespace std;
class cls{
	private:
		int x;
		public:
		inline void getdata()
	{
		cout<<"enter x:"<<endl;
		cin>>x;
		}			
	inline void output()
	{
		cout<<x;
	}
};
int main()
{
	cls c;
	c.getdata();
	c.output();
	
}
