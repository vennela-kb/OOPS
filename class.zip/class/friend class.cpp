#include<iostream>
using namespace std;
class first{
	friend class second;
	private:
		int x;
		public:
			void getdata()
			{
				cout<<"enter x:";
				cin>>x;
			}
		};
		class second {
		public: void output(class first f)
		{
			cout<<f.x<<endl;
			}	
		};
int main()
{
	first f1;
	second s1;
	f1.getdata();
	s1.output(f1);
}
