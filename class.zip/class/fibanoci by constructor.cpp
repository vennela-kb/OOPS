#include<iostream>
using namespace std;
class fibanocii
{
	private:
		int f0,f1,fib;
		public:
			fibanocii(){
				f0=0;
				f1=1;
				fib=f0+f1;
			}
void increament()
{	
	f0=f1;
	f1=fib;
	fib=f0+f1;
}
void output()
{
	cout<<fib<<"\t";
}
~fibanocii()
{
	cout<<"this is destructor";
}
};
int main()
{
	fibanocii f;
	for(int i;i<=15;i++){
	
	f.output();
	f.increament();
}
	
}
