#include<iostream>
using namespace std;
class stud
{
	private:
		char name[25];
		int rno;
	public:
	stud(){
		name[0]='\0';
		rno=0;
			}		
	void output()
	{
		cout<<name<<endl;
		cout<<rno<<endl;
	}
};
int main()
{
	stud s;
	s.output();
}

