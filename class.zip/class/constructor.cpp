#include<iostream>
using namespace std;
class class1{
	public:
		class1(){
			cout<<"this is constructor";
		}
		~class1(){
			cout<<"this is destructor";
		}		
};
int main()
{
	class1 c;
}
