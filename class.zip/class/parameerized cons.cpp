#include<iostream>
using namespace std;
class class1{
	int n,m;
	public: 
	class1(int x,int y)
	{
		n=x;
		m=y;
	}
void output()
{
	cout<<n<<endl;
	cout<<m<<endl;
	}
};
int main()
{
	class1 c(10,20);
	c.output();
}
