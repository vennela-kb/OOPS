#include<iostream>
using namespace std;
class sample
{
	int x;
	public:
		void output();
};
void sample::output()
{
	this->x=10;
	cout<<"contents:"<<this->x;
}
int main(){sample s;
s.output();
}
