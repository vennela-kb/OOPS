#include<iostream>
using namespace std;

class class1{
	int x;
	public:
		void getdata(){
			cout<<"enter x:"<<endl;
			cin>>x;
		}
		friend void output(class class1 c){
			cout<<c.x<<endl;
		}
};
int main()
{
	class1 c;
	c.getdata();
	output(c);
}
