#include<iostream>
using namespace std;
class class1{
	private: int p,n,r;
	float s;
	public: void input();
	void process();
	void output();
};
void class1::input(){
	cout<< "enter p,n,r:";
	cin>>p>>n>>r;
	
}
void  class1::process(){
	s=p*n*r/100;
}
void class1::output()
{
	cout<<"simple intrest:"<<s;
}
int main()
{
	class1 c;
	c.input();
	c.process();
	c.output();
}
